// Classe de entidade, model
export class Book {
  public id?: number;
  public title: string;
  public author: string;
  public year: number;

  constructor(title: string, author: string, year: number) {
    this.title = title;
    this.author = author;
    this.year = year;
  }
}
