import { Database } from "bun:sqlite";
import { Book } from "./book";

export class BookDAO {
  public db: Database;

  constructor() {
    this.db = new Database("./database.sqlite");
  }

  create(book: Book) {
    const query = `INSERT INTO books (title, author, year) VALUES ('${book.title}', '${book.author}', ${book.year})`;

    this.db.query(query).run();
  }

  update(book: Book) {
    const query = `UPDATE books SET title='${book.title}', author='${book.author}', year='${book.year}' WHERE id=${book.id}`;

    this.db.query(query).run();
  }

  remove(book: Book) {
    const query = `DELETE FROM books WHERE id=${book.id}`;

    this.db.query(query).run();
  }

  list(): Book[] {
    const query = "SELECT * FROM books";

    return this.db.query<Book, any>(query).all();
  }
}
